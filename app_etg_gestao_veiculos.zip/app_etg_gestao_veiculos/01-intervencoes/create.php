<?php
  include '../Login/config.php';
  //Pega os dados que o user inseriu e oloca na db;
  $tipo = $_POST["tipo"];
  $descricao = $_POST["descricao"];
  $data = $_POST["data"];
  $custo_peca = $_POST["custo_peca"];
  $custo_total = $_POST["custo_total"];
  $local = $_POST["local"];
  $n_intervencao = $_POST["n_intervencao"];
  $veiculo = $_POST["veiculo"];
  $n_veiculo = $_POST["n_veiculo"];
  $sql = "insert into intervencoes (tipo, descricao, data, custo_peca, custo_total, local, n_intervencao, veiculo, n_veiculo) values ('$tipo', '$descricao', '$data', '$custo_peca', '$custo_total', '$local', '$n_intervencao', '$veiculo', '$n_veiculo')";
  $conn->query($sql);
  $conn->close();
  header("location: tabela.php");


?>
