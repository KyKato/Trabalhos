<html>
<head>
  <link rel="stylesheet" href="../03-veiculos/css_ferramentas.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../Home/style.css">
</head>
<body>
  <header>
    <?php include '../Cabecalho/cabecalho.php'; ?>
    <br><br><br><br><br>

<div style="max-width:90%;" class="container">
  <h1 align="center">Intervenções:</h1>

  <form style="max-width:50%; margin: auto auto;" action="create.php" method="POST">
    Tipo: <input type="text" class="form-control m-2" id="tipo" name="tipo">
    Descrição: <input type="text" class="form-control m-2" id="descricao" name="descricao">
    Data: <input style="max-width:45%; margin: auto auto;" type="date" class="form-control m-2" id="data" name="data">
    Custo Por Peça: <input type="text" class="form-control m-2" id="custo_peca" name="custo_peca">
    Custo Total: <input type="text" class="form-control m-2" id="custo_total" name="custo_total">
    Local: <input type="text" class="form-control m-2" id="local" name="local">
    Nº da intervenção: <input type="text" class="form-control m-2" id="n_intervencao" name="n_intervencao">
    Veiculo: <input type="text" class="form-control m-2" id="veiculo" name="veiculo">
    Nº do Veículo: <input type="text" class="form-control m-2" id="n_veiculo" name="n_veiculo">


    <button type="submit" class="btn btn-primary">Adicionar</button>
    <br>&nbsp
  </form>
</div>
<div style="position: absolute; top: 20; right: 35; width: 150px; text-align:right; font-size: 15px;">
  <a href="../Home/principal.php"> <img width="50px" height="40px" src="back.png"></a>
</div>
</header>
</body>
</html>
