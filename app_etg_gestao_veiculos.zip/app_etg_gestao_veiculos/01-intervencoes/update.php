<?php
  include '../Login/config.php';
  $id = $_POST['id'];
  $tipo = $_POST["tipo"];
  $descricao = $_POST["descricao"];
  $data = $_POST["data"];
  $custo_peca = $_POST["custo_peca"];
  $custo_total = $_POST["custo_total"];
  $local = $_POST["local"];
  $n_intervencao = $_POST["n_intervencao"];
  $veiculo = $_POST["veiculo"];
  $n_veiculo = $_POST["n_veiculo"];
  $sql = "update intervencoes set tipo='$tipo', descricao='$descricao', data='$data', custo_peca='$custo_peca', custo_total='$custo_total', local='$local', n_intervencao='$n_intervencao', veiculo='$veiculo', n_veiculo='$n_veiculo' where id=$id";
  $result = $conn->query($sql);
  $conn->close();
  header("location: tabela.php");


?>
