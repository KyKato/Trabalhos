<?php
  include '../Login/config.php';
  //Pega os dados que o user inseriu e oloca na db;
  $tipo = $_POST["tipo"];
  $descricao = $_POST["descricao"];
  $condutor = $_POST["condutor"];
  $data = $_POST["data"];
  $feridos = $_POST["feridos"];
  $origem = $_POST["origem"];
  $intervencao = $_POST["intervencao"];
  $n_intervencao = $_POST["n_intervencao"];
  $veiculo = $_POST["veiculo"];
  $n_veiculo = $_POST["n_veiculo"];
  $sql = "insert into avarias (tipo, descricao, condutor, data, feridos, origem, intervencao, n_intervencao, veiculo, n_veiculo) values ('$tipo', '$descricao', '$condutor', '$data', '$feridos', '$origem', '$intervencao', '$n_intervencao', '$veiculo', '$n_veiculo')";
  $conn->query($sql);
  $conn->close();
  header("location: tabela.php");
?>
