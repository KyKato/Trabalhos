 <?php
  include '../fiscal/fiscal.php';
  include '../Login/config.php';
  $sql = "select * from avarias";
  $result = $conn->query($sql);
  while($row = $result->fetch_assoc()) {
    echo "<tr>";
    if ($row['id'] == $_GET['id']) {
      echo '<form class="form-inline m-2" action="update.php" method="POST">';
      echo '<td><input type="text" class="form-control" name="tipo" value="'.$row['tipo'].'"></td>';
      echo '<td><input type="text" class="form-control" name="descricao" value="'.$row['descricao'].'"></td>';
      echo '<td><input type="text" class="form-control" name="condutor" value="'.$row['condutor'].'"></td>';
      echo '<td><input type="date" class="form-control" name="data" value="'.$row['data'].'"></td>';
      echo '<td><input type="text" class="form-control" name="feridos" value="'.$row['feridos'].'"></td>';
      echo '<td><input type="text" class="form-control" name="origem" value="'.$row['origem'].'"></td>';
      echo '<td><input type="text" class="form-control" name="intervencao" value="'.$row['intervencao'].'"></td>';
      echo '<td><input type="text" class="form-control" name="n_intervencao" value="'.$row['n_intervencao'].'"></td>';
      echo '<td><input type="text" class="form-control" name="veiculo" value="'.$row['veiculo'].'"></td>';
      echo '<td><input type="text" class="form-control" name="n_veiculo" value="'.$row['n_veiculo'].'"></td>';
      echo '<td><button type="submit" class="btn btn-primary">Guardar</button></td>';
      echo '<input type="hidden" name="id" value="'.$row['id'].'">';
      echo '</form>';
    } else {
      echo "<td>" . $row['tipo'] . "</td>";
      echo "<td>" . $row['descricao'] . "</td>";
      echo "<td>" . $row['condutor'] . "</td>";
      echo "<td>" . $row['data'] . "</td>";
      echo "<td>" . $row['feridos'] . "</td>";
      echo "<td>" . $row['origem'] . "</td>";
      echo "<td>" . $row['intervencao'] . "</td>";
      echo "<td>" . $row['n_intervencao'] . "</td>";
      echo "<td>" . $row['veiculo'] . "</td>";
      echo "<td>" . $row['n_veiculo'] . "</td>";
      if ($perfil != 1) {
      echo '<td><a class="btn btn-primary" href="tabela.php?id=' . $row['id'] . '" role="button">Alterar</a></td>';
      echo '<td><a class="btn btn-danger" href="delete.php?id=' . $row['id'] . '" role="button">Apagar</a></td>';
      }
      echo "</tr>";
    }
  }
  if ($perfil == 3) {
  echo '<br>';
  echo '<a class="btn btn-primary" href="index.php" role="button">Criar</a></td>';
}
  $conn->close();
?>
