<?php
  include '../Login/config.php';
  $id = $_POST['id'];
  $tipo = $_POST['tipo'];
  $descricao = $_POST['descricao'];
  $condutor = $_POST['condutor'];
  $data = $_POST['data'];
  $feridos = $_POST['feridos'];
  $origem = $_POST['origem'];
  $intervencao = $_POST['intervencao'];
  $n_intervencao = $_POST['n_intervencao'];
  $veiculo = $_POST['veiculo'];
  $n_veiculo = $_POST['n_veiculo'];
  $sql = "update avarias set tipo='$tipo', descricao='$descricao', condutor='$condutor', data='$data', feridos='$feridos', origem='$origem', intervencao='$intervencao', n_intervencao='$n_intervencao', veiculo='$veiculo', n_veiculo='$n_veiculo' where id=$id";
  $result = $conn->query($sql);
  $conn->close();
  header("location: tabela.php");
?>
