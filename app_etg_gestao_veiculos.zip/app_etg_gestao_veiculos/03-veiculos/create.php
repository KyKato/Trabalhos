<?php
  include '../Login/config.php';
  //Pega os dados que o user inseriu e oloca na db;
  $marca = $_POST["marca"];
  $modelo = $_POST["modelo"];
  $matricula = $_POST["matricula"];
  $n_seguro = $_POST["n_seguro"];
  $seguradora = $_POST["seguradora"];
  $inspecao = $_POST["inspecao"];
  $tipo_combustivel = $_POST["tipo_combustivel"];
  $data_inspecao = $_POST["data_inspecao"];
  $data_aquisicao = $_POST["data_aquisicao"];
  $validade_seguro = $_POST["validade_seguro"];
  $responsavel = $_POST["responsavel"];
  $sql = "insert into veiculos (marca, modelo, matricula, n_seguro, seguradora, inspecao, tipo_combustivel, data_inspecao, data_aquisicao, validade_seguro, responsavel) values ('$marca', '$modelo', '$matricula' ,'$n_seguro' ,'$seguradora' ,'$inspecao' ,'$tipo_combustivel' ,'$data_inspecao' ,'$data_aquisicao' ,'$validade_seguro' ,'$responsavel')";
  $conn->query($sql);
  $conn->close();
  header("location: tabela.php");


?>
