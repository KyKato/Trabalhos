<?php
  include '../Login/config.php';
  $id = $_GET ['id'];
  $sql = "delete from veiculos where id =$id";
  $conn-> query($sql);
  $conn->close();
  header("location: tabela.php");


  ?>
