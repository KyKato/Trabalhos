<html>
<head>
  <link rel="stylesheet" href="css_ferramentas.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../Home/style.css">
</head>
<body>
  <header>
    <?php include '../Cabecalho/cabecalho.php'; ?>
    <br><br><br><br><br>
<div style="max-width:90%;" class="container">
  <h1 align="center">Veículos:</h1>

  <form style="max-width:50%; margin: auto auto;" action="create.php" method="POST">
    Marca:<input type="text" class="form-control m-2" id="marca" name="marca">
    Modelo:<input type="text" class="form-control m-2" id="modelo" name="modelo">
    Matrícula:<input type="text" class="form-control m-2" id="matricula" name="matricula">
    Nº Seguro:<input type="text" class="form-control m-2" id="n_seguro" name="n_seguro">
    Seguradora:<input type="text" class="form-control m-2" id="seguradora" name="seguradora">
    Inspeção:<input type="text" class="form-control m-2" id="inspecao" name="inspecao">
    Tipo Combustível:<input type="text" class="form-control m-2" id="tipo_combustivel" name="tipo_combustivel">
    Data da inspeção:<input style="max-width:45%; margin: auto auto;" type="date" class="form-control m-2" id="data_inspecao" name="data_inspecao">
    Data da aquisição:<input style="max-width:45%; margin: auto auto;" type="date" class="form-control m-2" id="data_aquisicao" name="data_aquisicao">
    Validade do Seguro:<input style="max-width:45%; margin: auto auto;" type="date" class="form-control m-2" id="validade_seguro" name="validade_seguro">
    Responsável pelo veículo:<input type="text" class="form-control m-2" id="responsavel" name="responsavel">
    <button type="submit" class="btn btn-primary">Adicionar</button>
    <br>&nbsp
  </form>
</div>
<div style="position: absolute; top: 20; right: 35; width: 150px; text-align:right; font-size: 15px;">
  <a href="../Home/principal.php"> <img width="50px" height="40px" src="back.png"></a>
</div>
</header>
</body>
</html>
