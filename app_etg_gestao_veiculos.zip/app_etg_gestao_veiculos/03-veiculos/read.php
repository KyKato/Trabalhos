<?php
 include '../fiscal/fiscal.php';
 include '../Login/config.php';
 $sql = "select * from veiculos";
 $result = $conn->query($sql);
 while($row = $result->fetch_assoc()) {
   echo "<tr>";
   if ($row['id'] == $_GET['id']) {
     echo '<form class="form-inline m-2" action="update.php" method="POST">';
     echo '<td><input type="text" class="form-control" name="marca" value="'.$row['marca'].'"></td>';
     echo '<td><input type="text" class="form-control" name="modelo" value="'.$row['modelo'].'"></td>';
     echo '<td><input type="text" class="form-control" name="matricula" value="'.$row['matricula'].'"></td>';
     echo '<td><input type="text" class="form-control" name="n_seguro" value="'.$row['n_seguro'].'"></td>';
     echo '<td><input type="text" class="form-control" name="seguradora" value="'.$row['seguradora'].'"></td>';
     echo '<td><input type="text" class="form-control" name="inspecao" value="'.$row['inspecao'].'"></td>';
     echo '<td><input type="text" class="form-control" name="tipo_combustivel" value="'.$row['tipo_combustivel'].'"></td>';
     echo '<td><input type="date" class="form-control" name="data_inspecao" value="'.$row['data_inspecao'].'"></td>';
     echo '<td><input type="date" class="form-control" name="data_aquisicao" value="'.$row['data_aquisicao'].'"></td>';
     echo '<td><input type="date" class="form-control" name="validade_seguro" value="'.$row['validade_seguro'].'"></td>';
     echo '<td><input type="text" class="form-control" name="responsavel" value="'.$row['responsavel'].'"></td>';
     echo '<td><button type="submit" class="btn btn-primary">Guardar</button></td>';
     echo '<input type="hidden" name="id" value="'.$row['id'].'">';
     echo '</form>';
   } else {

     echo "<td>" . $row['marca'] . "</td>";
     echo "<td>" . $row['modelo'] . "</td>";
     echo "<td>" . $row['matricula'] . "</td>";
     echo "<td>" . $row['n_seguro'] . "</td>";
     echo "<td>" . $row['seguradora'] . "</td>";
     echo "<td>" . $row['inspecao'] . "</td>";
     echo "<td>" . $row['tipo_combustivel'] . "</td>";
     echo "<td>" . $row['data_inspecao'] . "</td>";
     echo "<td>" . $row['data_aquisicao'] . "</td>";
     echo "<td>" . $row['validade_seguro'] . "</td>";
     echo "<td>" . $row['responsavel'] . "</td>";
    if ($perfil != 1) {
     echo '<td><a class="btn btn-primary" href="tabela.php?id=' . $row['id'] . '" role="button">Alterar</a></td>';
     echo '<td><a class="btn btn-danger" href="delete.php?id=' . $row['id'] . '" role="button">Apagar</a></td>';
     }
     echo "</tr>";
   }
 }
 if ($perfil == 3) {
 echo '<br>';
 echo '<a class="btn btn-primary" href="index.php" role="button">Criar</a></td>';
}
 $conn->close();
?>
