<?php include '../fiscal/fiscal.php'; ?>
<html>
<head>
  <link rel="stylesheet" href="css_ferramentas.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../Home/style.css">
</head>
<body>
  <header>
    <?php include '../Cabecalho/cabecalho.php';?>
    <br><br><br><br><br>
<!--<div class="mod">-->


<div style="max-width:90%;" class="container">
  <h1>Veículos:</h1>
  <table class="table">
    <th>Marca:</th>
    <th>Modelo:</th>
    <th>Matrícula:</th>
    <th>Nº Seguro:</th>
    <th>Seguradora:</th>
    <th>Inspeção:</th>
    <th>Tipo Combustível:</th>
    <th>Data da inspeção:</th>
    <th>Data da aquisição:</th>
    <th>Validade do Seguro:</th>
    <th>Responsável:</th>
    <?php if ($perfil != 1) { ?>
    <th>Ações:</th>
    <th>&nbsp</th>
    <?php } ?>
    <tbody>
      <?php include 'read.php'; ?>
    </tbody>
  </table>
  <div style="position: absolute; top: 20; right: 35; width: 150px; text-align:right; font-size: 15px;">
    <a href="../Home/principal.php"> <img width="50px" height="40px" src="back.png"></a>
  </div>
</header>
</body>
</html>
