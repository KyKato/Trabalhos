<?php
  include '../Login/config.php';
  $id = $_POST['id'];
  $marca = $_POST['marca'];
  $modelo = $_POST['modelo'];
  $matricula = $_POST['matricula'];
  $n_seguro = $_POST['n_seguro'];
  $seguradora = $_POST['seguradora'];
  $inspecao = $_POST['inspecao'];
  $tipo_combustivel = $_POST['tipo_combustivel'];
  $data_inspecao = $_POST['data_inspecao'];
  $data_aquisicao = $_POST['data_aquisicao'];
  $validade_seguro = $_POST['validade_seguro'];
  $responsavel = $_POST["responsavel"];
  $sql = "update veiculos set marca='$marca', modelo='$modelo', matricula='$matricula', n_seguro='$n_seguro', seguradora='$seguradora', inspecao='$inspecao', tipo_combustivel='$tipo_combustivel', data_inspecao='$data_inspecao', data_aquisicao='$data_aquisicao', validade_seguro='$validade_seguro', responsavel='$responsavel' where id=$id";
  $result = $conn->query($sql);
  $conn->close();
  header("location: tabela.php");


?>
