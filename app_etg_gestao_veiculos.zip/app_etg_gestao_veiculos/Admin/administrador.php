<?php include '../fiscal/fiscal.php'; ?>
<html>
<head>
  <link rel="stylesheet" href="../03-veiculos/css_ferramentas.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../Home/style.css">
</head>
<body>
  <header>
    <?php include '../Cabecalho/cabecalho.php';?>
    <br><br><br><br><br>
<div class="mod">


<div style="max-width:75%;" class="container">
  <h1>Utilizadores:</h1>
  <table class="table">
    <th>ID:</th>
    <th>Nome:</th>
    <th>Email:</th>
    <th>Perfil:</th>
    <th>Ações:</th>
    <tbody>
      <?php include 'administrador_data.php'; ?>
    </tbody>
  </table>
</header>
</body>
</html>
