<?php
include '../fiscal/fiscal.php';
?>
<html>
  <head>
    <header>
      <?php include '../Cabecalho/cabecalho.php';?>

      <meta charset="UTF-8">
      <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="style.css">
    </head>
  <body>
    <div class="welcome-text">
      <h1>Gestão de <span>Veículos</span></h1>
      <?php if ($perfil == 1) { ?><?php echo "<h3>&nbsp Bem Vindo " . $_SESSION['gestao_veiculos']['username'] . "!&nbsp</h3>"; ?><?php } ?>
      <h3><?php print_r ($_SESSION); echo '$perfil ='; echo $perfil;  ?></h3>
      <h3><?php echo $_SESSION ['gestao_veiculos']['registration_date']; ?></h3>
      <h3><?php
          echo date('Y-m-d H:i:s', strtotime('+1day', strtotime($_SESSION ['gestao_veiculos']['registration_date'])));
      ?></h3>
    </div>
    </header>
  </body>
</html>
