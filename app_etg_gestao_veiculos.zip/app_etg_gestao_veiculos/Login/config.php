<?php

$server = "SRVPTSQL02";
$user = "informatica";
$pass = "informatica";
$database = "gestao_veiculos";

$conn = mysqli_connect($server, $user, $pass, $database);

if (!$conn) {
    die("<script>alert('Connection Failed.')</script>");
}

?>
