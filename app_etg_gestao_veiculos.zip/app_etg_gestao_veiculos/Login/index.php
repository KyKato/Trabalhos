<?php

include 'config.php';

session_start();

error_reporting(0);

//Se o botão for pressionado verificar email e encriptar palavara passe;
if (isset($_POST['submit'])) {
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$sql = "SELECT id, username, perfil, data_limite FROM users WHERE email='$email' AND password='$password'";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION ['gestao_veiculos'] = $row;
		if (time() >= strtotime($_SESSION ['gestao_veiculos']['data_limite'])) {
			header("Location: ../Password_reset/password_reset.php"); exit;
		}
		header("Location: ../Home/principal.php"); exit;
	} else {
		echo "<script>alert('Woops! Email ou Palavra-passe estão erradas.')</script>";
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="style.css">


</head>
<body>
	<div class="container">
		<form action="" method="POST" class="login-email">
			<p class="login-text" style="font-size: 2rem; font-weight: 800;">Login</p>
			<div class="input-group">
				<input type="email" placeholder="Email" name="email" value="<?php echo $email; ?>" required>
			</div>
			<div class="input-group">
				<input type="password" placeholder="Palavra-passe" name="password" value="<?php echo $_POST['password']; ?>" required>
			</div>
			<div class="input-group">
				<button name="submit" class="btn">Entrar</button>
			</div>
			<p class="login-register-text">Não têm uma conta? <a href="register.php">Registre-se agora</a>!</p>
		</form>
	</div>
</body>
</html>
