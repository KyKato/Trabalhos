<?php
include '../Login/config.php';

session_start();

error_reporting(0);
if (isset($_POST['submit'])) {
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$cpassword = md5($_POST['cpassword']);
  $data_limite = date ('Y-m-d H:i:s' , strtotime ('+60day', time ()));

	if ($password == $cpassword) {
		$sql = "SELECT * FROM users WHERE email='$email'";
		$result = mysqli_query($conn, $sql);
		if ($result->num_rows > 0) {
			$sql = "UPDATE users SET password = '$password', data_limite = '$data_Limite' WHERE email='$email'";
			$row = mysqli_fetch_assoc($result);
			$_SESSION ['gestao_veiculos'] = $row;
			echo "<script>alert('Alteração de palara-passe Com sucesso.')</script>";
			header("Location: ../Home/principal.php"); exit;
		} else {
			echo "<script>alert('Algo deu errado.')</script>";
			header('Location: ..index.php');
		}

	} else {
		echo "<script>alert('Palavras-passes não coincidem.')</script>";
	}
}



	?>


<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="..\login\style.css">


</head>
<body>
	<div class="container">
		<form action="" method="POST" class="login-email">
			<p class="login-text" style="font-size: 2rem; font-weight: 800;">Alteração da password</p>
			<div class="input-group">
				<input type="email" placeholder="Email" name="email" value="<?php echo $email; ?>" required>
			</div>
			<div class="input-group">
				<input type="password" placeholder="Palavra-passe" name="password" value="<?php echo $_POST['password'];?>" required>
			</div>
			<div class="input-group">
			<input type="password" placeholder="Confirmar palavra-passe" name="cpassword" value="<?php echo $_POST['cpassword']; ?>" required>
		</div>
			<div class="input-group">
	<button name="submit" class="btn">Salvar alterações</button>
			</div>
		</form>
	</div>
</body>
</html>
