
<html>
    <head></head>
        <body>

        <form methos="$_POST" action="index.php">
            <label for="num"> Insira o número: </label><br>
            <input type="number" id="num"> <br>
            <input type="submit" name="enviar">
        </form>

     <?php

        if (isset($_POST['Enviar']))
            {
              $numero = $_POST['num'];
              
            if($number > 0){
                    echo " $number é um número positivo  ";
                    }
                elseif($number < 0){
                    echo " $number é um número negativo ";
                }
                    else {
                        echo"$number é igual a 0";
                    }
        
     ?>   
</body>
</html>
    



    