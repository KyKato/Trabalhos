<?php
session_start();

if (!isset($_SESSION['gestao_veiculos'])) {
    header("Location: ../Login/index.php");
}

$id_utilizador = $_SESSION ['id'];
$perfil =$_SESSION['gestao_veiculos']['perfil'];

?>
