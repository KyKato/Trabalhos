<?php
if ($stmt = $mysqli->prepare('SELECT * FROM medicamentos ORDER BY ID LIMIT ?,?')) {
	// Calculate the page to get the results we need from our table.
	$calc_page = ($page - 1) * $num_results_on_page;
	$stmt->bind_param('ii', $calc_page, $num_results_on_page);
	$stmt->execute();
	// Get the results...
	$result = $stmt->get_result();
	$stmt->close();
}
$total_pages = $mysqli->query('SELECT COUNT(*) FROM medicamentos')->fetch_row()[0];
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;
$num_results_on_page = 5;
?>
