<?php
  include '../Login/config.php';
  //Pega os dados que o user inseriu e oloca na db;

  $nome = $_POST["nome"];
  $principio = $_POST["principio"];
  $dose = $_POST["dose"];
  $unidades = $_POST["unidades"];
  $quantia = $_POST["quantia"];
  $apagado = 0; // $_POST["apagado"];
  $existencia_minima = $_POST["existencia_minima"];

//echo $nome.' <br> '.$principio.' <br> '.$dose.' <br> '.$unidades.' <br> '.$quantia.' <br> '.$apagado.' <br> '.$existencia_minima;
//exit;
 $sql = "INSERT INTO medicamentos (nome, principio, dose, unidades, quantia, apagado, existencia_minima)
        values ('$nome', '$principio', $dose, $unidades , $quantia, '$apagado', $existencia_minima)";

  //$sql = "INSERT INTO medicamentos (nome, principio, dose, unidades, quantia, apagado, existencia_minima)
    //      values ('$nome', '$principio', $dose, '$unidades', $quantia, '$apagado', $existencia_minima)";

  $pedido = $conn->query($sql);

  //if ($pedido) echo 'sim' else echo 'nao';

  //exit;

  $conn->close();
  header("location: tabela.php");
?>
