<html>
<head>
  <link rel="stylesheet" href="css_ferramentas.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../Home/style.css">
</head>
<body>
  <header>
    <?php include '../Cabecalho/cabecalho.php'; ?>
    <?php include 'unidades.php'; ?>
    <br><br><br><br><br>
<div style="max-width:90%;" class="container">
  <h1 align="center">Medicamento:</h1>

  <form style="max-width:50%; margin: auto auto;" action="create.php" method="POST">
    Nome:<input type="text" class="form-control m-2" id="nome" name="nome">
    Descrição:<input type="text" class="form-control m-2" id="principio" name="principio">
    Dose:<input type="number" class="form-control m-2" id="dose" name="dose">
    Unidades:<br>
  <?php $unidades_medicacao = array (1 => array ('gm', 'grama'),
                                       2 => array ('ml', 'miligrama'),
                                       3 => array ('mc', 'micrograma')
                                      )
    ?>
    <select class="form-control m-2" name="unidades" id="unidades">
     <option value="0"></option>
     <?php foreach ($unidades_medicacao as $indice => $unidades) { ?>
      <option value="<?php echo $indice; ?>"><?php echo $unidades [0]; ?></option>
    <?php } ?>
    </select>

    <!-- <select class="form-control m-2" name="unidades" id="unidades">
      <option value="grama">Grama</option>
      <option value="micrograma">micrograma</option>
      <option value="miligrama">miligrama</option>
    </select> -->
    Quantia:<input type="number" class="form-control m-2" id="quantia" name="quantia">
    Apagado:<br>
    <?php $unidade_apagado = array (1 => array ('Sim'),
                                         2 => array ('Não')
                                        )
      ?>
    <input type="text" class="form-control m-2" id="apagado" name="apagado">
    <option value="0"></option>
    <?php foreach ($unidade_apagado as $indice1 => $unidades1) { ?>
     <option value="<?php echo $indice1; ?>"><?php echo $unidades1 [0]; ?></option>
   <?php } ?>
    Existencia minima:<input type="text" class="form-control m-2" id="existencia_minima" name="existencia_minima">

     <button type="submit" class="btn btn-primary">Adicionar</button>
    <br>&nbsp
  </form>
</div>
<div style="position: absolute; top: 20; right: 35; width: 150px; text-align:right; font-size: 15px;">
  <a href="../Home/principal.php"> <img width="50px" height="40px" src="back.png"></a>
</div>
</header>
</body>
</html>
