
<?php
include '../Cabecalho/cabecalho.php';

$server = "SRVPTSQL02";
$user = "informatica";
$pass = "informatica";
$database = "gestao_medicacao";

$conn = mysqli_connect($server, $user, $pass, $database);

if (!$conn) {
    die("<script>alert('Falha na conexão.')</script>");
}


$limit = 9;
if (isset($_GET["page"])) {
	$page  = $_GET["page"];
	}
	else{
	$page=1;
	};
$start_from = ($page-1) * $limit;
$result = mysqli_query($conn,"SELECT * FROM medicamentos ORDER BY ID ASC LIMIT $start_from, $limit");
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css_ferramentas.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../Home/style.css">
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>-->
</head>
<body>
    <!--<h1 align="center">Medicamento:</h1>-->
    <?php  {
    echo '<br>';
    echo '<a class="btn btn-primary" href="index.php" role="button">Criar</a></td>';
    }
    ?>
<table class="table table-bordered table-striped" style="max-width:99%; margin: auto auto;">
<thead>
<tr>

<th>Nome</th>
<th>Principio</th>
<th>dose</th>
<th>unidades</th>
 <th>quantia</th>
<th>apagado</th>
<th>existencia minima</th>
<th> Ações <th>
</tr>
<thead>
<tbody>
<?php
while ($row = mysqli_fetch_array($result)) {
?>
            <tr>

				<td><?php echo $row["nome"]; ?></td>
				<td><?php echo $row["principio"]; ?></td>
				<td><?php echo $row["dose"]; ?></td>
        <td><?php if($row["unidades"] == 1){
                  echo 'grama';
                }elseif ($row["unidades"] == 2) {
                  echo 'miligrama';
                }elseif ($row["unidades"] == 3) {
                  echo 'micrograma';
                }
        ?></td>
				<td><?php echo $row["quantia"]; ?></td>
        <td><?php echo $row["apagado"]; ?></td>
        <td><?php echo $row["existencia_minima"]; ?></td>
        <td><?php echo'<a class="btn btn-primary" href="update.php?id=' . $row['id']. '" role="button">Alterar</a>'?></td>
        <td>  <?php echo'<a class="btn btn-danger" href="delete.php?id=' . $row['id'] . '" role="button">Apagar</a>'?></td>

            </tr>
<?php
};
?>
</tbody>
</table>
<?php

$result_db = mysqli_query($conn,"SELECT COUNT(id) FROM medicamentos");
$row_db = mysqli_fetch_row($result_db);
$total_records = $row_db[0];
$total_pages = ceil($total_records / $limit);
/* echo  $total_pages; */
$pagLink = "<ul class='pagination'>";
for ($i=1; $i<=$total_pages; $i++) {
              $pagLink .= "<li class='page-item'><a class='page-link' href='pagination.php?page=".$i."'>".$i."</a></li>";
}
echo $pagLink . "</ul>";
?>

</body>
</html>
