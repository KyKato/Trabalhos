<?php

$server = "SRVPTSQL02";
$user = "informatica";
$pass = "informatica";
$database = "gestao_medicacao";

$conn = mysqli_connect($server, $user, $pass, $database);

if (!$conn) {
    die("<script>alert('Falha na conexão.')</script>");
}


$limit = 5;
if (isset($_GET["page"])) {
	$page  = $_GET["page"];
	}
	else{
	$page=1;
	};
$start_from = ($page-1) * $limit;
$result = mysqli_query($conn,"SELECT * FROM medicamentos ORDER BY ID ASC LIMIT $start_from, $limit");
?>
<?php
 include '../fiscal/fiscal.php';
 include '../Login/config.php';
 include 'condadorpag.php';

   $sql = "select * from medicamentos";
 $result = $conn->query($sql);
 while($row = $result->fetch_assoc()) {
   echo "<tr>";
   if ($row['id'] == $_GET['id']) {
     echo '<form class="form-inline m-2" action="update.php" method="POST">';
     echo '<td><input type="text" class="form-control" name="nome" value="'.$row['nome'].'"></td>';
     echo '<td><input type="text" class="form-control" name="principio" value="'.$row['principio'].'"></td>';
     echo '<td><input type="text" class="form-control" name="dose" value="'.$row['dose'].'"></td>';
     echo '<td><select  class="form-control" name="unidades" value="'.$row['unidades'].'">
     <option value="grama">Grama</option>
     <option value="micrograma">Micrograma</option>
     <option value="miligrama">Miligrama</option>
     </select></td>';
     echo '<td><input type="text" class="form-control" name="quantia" value="'.$row['quantia'].'"></td>';
     echo '<td><input type="text" class="form-control" name="apagado" value="'.$row['apagado'].'"></td>';
     echo '<td><input type="number" class="form-control" name="existencia_minima" value="'.$row['existencia_minima'].'"</td>';
     echo '<input type="hidden" name="id" value="'.$row['id'].'">';
     echo '</form>';
   } else {

     echo "<td>" . $row['nome'] . "</td>";
     echo "<td>" . $row['principio'] . "</td>";
     echo "<td>" . $row['dose'] . "</td>";
     echo "<td>" . $row['unidades'] . "</td>";
     echo "<td>" . $row['quantia'] . "</td>";
     echo "<td>" . $row['apagado'] . "</td>";
     echo "<td>" . $row['existencia_minima'] . "</td>";
     echo '<td><a class="btn btn-primary" href="tabela.php?id=' . $row['id']. '" role="button">Alterar</a></td>';
     echo '<td><a class="btn btn-danger" href="delete.php?id=' . $row['id'] . '" role="button">Apagar</a></td>';
     }
     echo "</tr>";

     };
     ?>
     </tbody>
     </table>
     <?php

     $result_db = mysqli_query($conn,"SELECT COUNT(id) FROM medicamentos");
     $row_db = mysqli_fetch_row($result_db);
     $total_records = $row_db[0];
     $total_pages = ceil($total_records / $limit);
     /* echo  $total_pages; */
     $pagLink = "<ul class='pagination'>";
     for ($i=1; $i<=$total_pages; $i++) {
                   $pagLink .= "<li class='page-item'><a class='page-link' href='pagination.php?page=".$i."'>".$i."</a></li>";
     }
     echo $pagLink . "</ul>";
     ?>
   }
<?php
if ($perfil >= 1) {
 echo '<br>';
 //echo '<a class="btn btn-primary" href="index.php" role="button">Criar</a></td>';
}
 $conn->close();
?>
