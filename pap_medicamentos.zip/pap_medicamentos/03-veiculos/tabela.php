<?php
$server = "SRVPTSQL02";
$user = "informatica";
$pass = "informatica";
$database = "gestao_medicacao";

$conn = mysqli_connect($server, $user, $pass, $database);

if (!$conn) {
    die("<script>alert('Falha na conexão.')</script>");
}


$limit = 5;
if (isset($_GET["page"])) {
	$page  = $_GET["page"];
	}
	else{
	$page=1;
	};
$start_from = ($page-1) * $limit;
$result = mysqli_query($conn,"SELECT * FROM medicamentos ORDER BY ID ASC LIMIT $start_from, $limit");
?>
<!--http://srvptapp/pap_medicamentos/03-veiculos/tabela.php?id=%27%20.%20$row[%27id%27].%20%27-->

<html>
<head>
  <link rel="stylesheet" href="css_ferramentas.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../Home/style.css">
</head>
<body>
  <header>
    <?php include '../Cabecalho/cabecalho.php';?>
    <br><br><br><br><br>


<div style="max-width:90%;" class="container">
  <h1>Medicamentos:</h1>
  <?php  {
echo '<br>';
echo '<a class="btn btn-primary" href="index.php" role="button">Criar</a></td>';
}
?>
<br></br>
  <table class="table">
    <th>Nome:</th>
    <th>Descrição:</th>
    <th>Dose:</th>
    <th>Unidade:</th>
    <th>Quantidade:</th>
    <th>Existencia minima:</th>
    <th>Apagado:</th>
    <?php if ($perfil != 1) { ?>
    <th>Ações:</th>
    <th>&nbsp</th>
    <?php } ?>
    <tbody>
    <?php include 'read.php'; ?>

    </tbody>
  </table>
  <?php

  $result_db = mysqli_query($conn,"SELECT COUNT(ID) FROM medicamentos");
  $row_db = mysqli_fetch_row($result_db);
  $total_records = $row_db[0];
  $total_pages = ceil($total_records / $limit);
  /* echo  $total_pages; */
  $pagLink = "<ul class='pagination'>";
  for ($i=1; $i<=$total_pages; $i++) {
                $pagLink .= "<li class='page-item'><a class='page-link' href='pagination.php?page=".$i."'>".$i."</a></li>";
  }
  echo $pagLink . "</ul>";
  ?>
  <div style="position: absolute; top: 20; right: 35; width: 150px; text-align:right; font-size: 15px;">
    <a href="../Home/principal.php"> <img width="50px" height="40px" src="back.png"></a>
  </div>
</header>
</body>
</html>
