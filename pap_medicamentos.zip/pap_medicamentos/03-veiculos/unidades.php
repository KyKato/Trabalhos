<?php $unidades_medicacao = array (1 => array ('gm', 'grama'),
                                   2 => array ('ml', 'miligrama'),
                                   3 => array ('mc', 'micrograma')
                                  )
?>
