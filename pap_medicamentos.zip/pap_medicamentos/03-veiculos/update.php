<?php
  include '../Login/config.php';
  $id = $_POST['id'];
  $nome = $_POST["nome"];
  $principio = $_POST["principio"];
  $dose = $_POST["dose"];
  $unidades = $_POST["unidades"];
  $quantia = $_POST["quantia"];
  $apagado = $_POST["apagado"];
  $existencia_minima = $_POST["existencia_minima"];
  $sql = "UPDATE medicamentos set nome='$nome', principio='$principio', dose='$dose', unidades='$unidades', quantia='$quantia', existencia_minima='$existencia_minima', apagado='$apagado' where id='$id'";
  $result = $conn->query($sql);
  $conn->close();
  header("location: tabela.php");


?>
