<?php
  include '../Login/config.php';
  $sql = "SELECT id, username, email, perfil FROM users";
  $result = mysqli_query($conn, $sql);
  if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      echo "<tr><td>" . $row['id'] .
      "</td><td>" . $row['username'] .
      "</td><td>" . $row['email'] .
      "</td><td>" . $row['perfil'] . "</td>";
      echo '<td><a class="btn btn-danger" href="delete.php?id=' . $row['id'] . '" role="button">Apagar</a></td>';
      echo "</tr>";

    }
  }







?>
