

 <div class="wrapper">
   <div class="logo" style="height: 100px; ">
       <br><br><br><br>
       &nbsp&nbsp&nbsp&nbsp<a target="blank" href="https://www.sns.gov.pt/"><img width="276" height="47" src="../Home/Imagens/logotipo1.png"></a>
   </div>
   <ul class="nav-area">
   <li><a href="../Home/principal.php">Início</a></li>
   <?php //if ($perfil == 1) { ?>

   <li><a href="../03-veiculos/pagination.php">Inventário</a></li><?php //} ?>
   <?php if ($perfil == 3) { ?><li><a href="../Admin/administrador.php">Administrar</a></li><?php } ?>
   <li><a href="../Login/logout.php">Fechar Sessão</a></li>
 </ul>
 </div>
