<html>
    <head>
    <title>Ex 3</title>
    </head>
        <body>
     <?php
      if (isset($_POST['Enviar'])){
        $num = $_POST['numero'];
        $num2 = $_POST['numero2'];
        $c = 0;
        $pares = 'Pares =';
        $impares = 'Impares =';

        if($num < $num2){
            while($num < $num2) {
                if($num % 2 == 0){
                    $pares .= $num." ";
                }else{
                    $impares .= $num." ";
                }
                
                $num++;
            }   
            echo $pares."<br>";
            echo $impares;
        } else{ 
            echo"O primeiro número é superior ao segundo numero";
            exit;
        }
        
    } else { 
       ?>   
        <form method ="Post" action ="Index.php">
            <label for="number">Indique o número: </lable> <br> 
            <input type="number" name="numero"><br>
            <label for="number">Indique o segundo número: </lable> <br> 
            <input type="number" name="numero2"><br>
            <input type="Submit" name="Enviar">
        </form>

    <?php } ?>
    </body>
</html>