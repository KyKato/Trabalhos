<?php

$server = "SRVPTSQL02";
$user = "informatica";
$pass = "informatica";
$database = "gestao_medicacao";

$conn = mysqli_connect($server, $user, $pass, $database);

if (!$conn) {
    die("<script>alert('Falha na conexão.')</script>");
}

?>
