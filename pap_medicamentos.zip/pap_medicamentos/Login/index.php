<?php

include 'config.php';
include 'login.php';

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="style.css">


</head>
<body>
	<div class="container">
		<form action="" method="POST" class="login-email">
			<p class="login-text" style="font-size: 2rem; font-weight: 800;">Login</p>
			<div class="input-group">
				<input type="email" placeholder="Email" name="email" value="<?php echo $email; ?>" required>
			</div>
			<div class="input-group">
				<input type="password" placeholder="Palavra-passe" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Necessita ter pelo menos um número, uma letra minúscula e uma letra maiúsluca, e conter no mínimo 8 caractéres" name="password" value="<?php echo $_POST['password']; ?>" required>
			</div>
			<div class="input-group">
				<button name="submit" class="btn">Entrar</button>
			</div>
			<p class="login-register-text">Não têm uma conta? <a href="register.php">Registre-se agora</a>!</p>
		<center><p class="login-register-text">Perdeu a Password? <a href="../password_reset/password_reset.php">Recupere</a>!</p>
		</form>
	</div>
</body>
</html>
