<?php

include 'config.php';

session_start();

error_reporting(0);

//Se o botão for pressionado verificar email e encriptar palavara passe;
if (isset($_POST['submit'])) {
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$sql = "SELECT id, username, perfil, data_limite FROM users WHERE email='$email' AND password='$password'";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION ['gestao_medicacao'] = $row;
		if (time() >= strtotime($_SESSION ['gestao_medicacao']['data_limite'])) {
			header("Location: ../Password_reset/password_reset.php"); exit;
		}
		header("Location: ../Home/principal.php"); exit;
	} else {
		echo "<script>alert('Woops! Email ou Palavra-passe estão erradas.')</script>";
	}
}
?>
