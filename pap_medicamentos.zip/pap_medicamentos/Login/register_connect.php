<?php
  include 'config.php';

  error_reporting(0);

  session_start();

  if (isset($_SESSION['gestao_medicacao'])) {
      header("Location: index.php");
  }

  if (isset($_POST['submit'])) {
    $id = $_POST['gestao_medicacao'];
  	$username = $_POST['username'];
  	$email = $_POST['email'];
  	$password = md5($_POST['password']);
  	$cpassword = md5($_POST['cpassword']);
    $perfil = 1;
    $data_limite = date ('Y-m-d H:i:s' , strtotime ('+60day', time ()));

  	if ($password == $cpassword) {
  		$sql = "SELECT * FROM users WHERE email='$email'";
  		$result = mysqli_query($conn, $sql);
  		if (!$result->num_rows > 0) {
  			$sql = "INSERT INTO users (username, email, password, perfil, data_limite)
  					VALUES ('$username', '$email', '$password','$perfil', '$data_limite')";
  			$result = mysqli_query($conn, $sql);
  			if ($result) {
  				echo "<script>alert('Wow! Registrado com sucesso.')</script>";
  				$username = "";
  				$email = "";
  				$_POST['password'] = "";
  				$_POST['cpassword'] = "";
          $perfil = "";

  			} else {
  				echo "<script>alert('Woops!  Algo correu errado.')</script>";
  			}
  		} else {
  			echo "<script>alert('Woops! Este email já existe.')</script>";
  		}

  	} else {
  		echo "<script>alert('Palavras-passes não coincidem.')</script>";
  	}
  }

 ?>
