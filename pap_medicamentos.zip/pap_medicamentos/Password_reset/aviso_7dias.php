<?php
  include 'config.php';

  $aviso = date ('Y-m-d H:i:s' , strtotime ('-1 week', time ()));

 if ($aviso == strtotime($_SESSION ['gestao_medicacao']['data_limite'])) {
  echo "<script>alert('A validade da sua palavra-passe expira em 7 dias.')</script>"; exit;
}?>
