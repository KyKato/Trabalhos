<?php
include '../Login/config.php';

if (isset($_POST['submit'])) {
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$cpassword = md5($_POST['cpassword']);
  $data_limite = date ('Y-m-d H:i:s' , strtotime ('+60day', time ()));
	if ($password == $cpassword) {
		$sql = "SELECT id, username, perfil, data_limite FROM users WHERE email LIKE '$email'";
		$result = mysqli_query($conn, $sql);

		if ($result->num_rows > 0) {
			$_SESSION ['gestao_medicacao'] = $row;
			$sql = "UPDATE users SET password = '$password', data_limite = '$data_limite' WHERE email LIKE '$email'";
			$result = mysqli_query($conn, $sql);

echo $result;

exit;

			echo "<script>alert('Alteração de palara-passe Com sucesso.')</script>";
			header('Location: ../Home/principal.php');

		} else {
			echo "<script>alert('Algo deu errado.')</script>";
			header('Location: ../index.php');
		}

	} else {
		echo "<script>alert('Palavras-passes não coincidem.')</script>";
	}

exit;
}
 ?>
