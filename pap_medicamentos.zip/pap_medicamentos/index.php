<!DOCTYPE html><html>
<head>
    <title> . INEM Gestão de Veículos . </title>

    <meta charset="utf-8">
    <meta name="handheldFriendly" content="true">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--[if IE]><link rel="shortcut icon" href="favicon.ico"><![endif]-->
    <link rel="shortcut icon" href="favicon.png">
</head>

    <frameset rows="100%,*" frameborder="no" framespacing=0 border=0>
    <frame name="miolo" src="Home/principal.php" noresize marginwidth="0" marginheight="0">
    </frameset>

    <noframes>
<body bgcolor="#FFFFFF" text="#000000">
    <p align="center"><font face="Arial" size="1">&nbsp;</font></p>
</body>
    </noframes>
</html>
